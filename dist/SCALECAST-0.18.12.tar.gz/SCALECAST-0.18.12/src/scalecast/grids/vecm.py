vecm = {
    'lags':[0],
    'normalizer':[None],
    'k_ar_diff':[1,2,3,4,5,6,7],
    'deterministic':["n","co","lo","li","cili","colo"],
    'seasons':[0,12],
}