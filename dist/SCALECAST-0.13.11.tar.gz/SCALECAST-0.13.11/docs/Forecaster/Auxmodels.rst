auxmodels
============================================

Supplemental models that build on scalecast's functionality.

auto_arima()
-----------------------------
.. automodule:: src.scalecast.auxmodels.auto_arima
    :members:

mlp_stack()
-----------------------------
.. automodule:: src.scalecast.auxmodels.mlp_stack
    :members: