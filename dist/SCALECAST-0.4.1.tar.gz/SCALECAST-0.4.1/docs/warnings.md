## warnings
- all forecast runs creates a log file called warnings.log that should store any warnings from any of the models so they don't print to console